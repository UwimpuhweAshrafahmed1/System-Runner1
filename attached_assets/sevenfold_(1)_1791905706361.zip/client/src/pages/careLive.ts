import { useEffect, useState } from "react";
import { trpc } from "@/lib/trpc";

export function useAppointmentLiveRefresh(enabled: boolean) {
  const utils = trpc.useUtils();
  const [status, setStatus] = useState<"offline" | "connecting" | "live" | "reconnecting">("offline");

  useEffect(() => {
    if (!enabled) {
      setStatus("offline");
      return;
    }
    setStatus("connecting");
    const refresh = () => {
      void utils.care.mine.invalidate();
      void utils.care.staffQueue.invalidate();
      void utils.care.providers.invalidate();
      void utils.care.slots.invalidate();
    };
    const source = new EventSource("/api/appointments/events");
    source.onopen = () => setStatus("live");
    source.onerror = () => setStatus("reconnecting");
    source.addEventListener("appointments.changed", refresh);
    return () => {
      source.removeEventListener("appointments.changed", refresh);
      source.close();
    };
  }, [enabled, utils]);

  return status;
}
