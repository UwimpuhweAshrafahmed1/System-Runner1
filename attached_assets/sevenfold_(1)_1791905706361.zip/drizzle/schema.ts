import { int, index, mysqlEnum, mysqlTable, text, timestamp, uniqueIndex, varchar } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 */
export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  accountType: mysqlEnum("accountType", ["patient", "clinic", "partner", "admin"]).default("patient").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

export const clinics = mysqlTable("clinics", {
  id: int("id").autoincrement().primaryKey(),
  code: varchar("code", { length: 32 }).notNull().unique(),
  slug: varchar("slug", { length: 100 }).notNull().unique(),
  name: varchar("name", { length: 180 }).notNull(),
  country: varchar("country", { length: 100 }).notNull(),
  city: varchar("city", { length: 100 }).notNull(),
  timezone: varchar("timezone", { length: 80 }).notNull().default("UTC"),
  contactEmail: varchar("contactEmail", { length: 320 }),
  phone: varchar("phone", { length: 40 }),
  isActive: int("isActive").notNull().default(1),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});
export type Clinic = typeof clinics.$inferSelect;
export type InsertClinic = typeof clinics.$inferInsert;

export const clinicMembers = mysqlTable("clinic_members", {
  id: int("id").autoincrement().primaryKey(),
  clinicId: int("clinicId").notNull(),
  userId: int("userId").notNull(),
  jobTitle: varchar("jobTitle", { length: 120 }),
  isPrimary: int("isPrimary").notNull().default(0),
  isActive: int("isActive").notNull().default(1),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, table => ({
  membershipUnique: uniqueIndex("clinic_members_clinic_user_uq").on(table.clinicId, table.userId),
  userIndex: index("clinic_members_user_idx").on(table.userId, table.isActive),
}));
export type ClinicMember = typeof clinicMembers.$inferSelect;
export type InsertClinicMember = typeof clinicMembers.$inferInsert;

export const patients = mysqlTable("patients", {
  id: int("id").autoincrement().primaryKey(),
  patientCode: varchar("patientCode", { length: 32 }).notNull().unique(),
  userId: int("userId").notNull().unique(),
  firstName: varchar("firstName", { length: 100 }),
  lastName: varchar("lastName", { length: 100 }),
  phone: varchar("phone", { length: 40 }),
  email: varchar("email", { length: 320 }),
  country: varchar("country", { length: 100 }),
  language: varchar("language", { length: 80 }),
  status: mysqlEnum("status", ["new", "active", "follow_up", "archived"]).notNull().default("new"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, table => ({
  statusIndex: index("patients_status_idx").on(table.status, table.updatedAt),
}));
export type Patient = typeof patients.$inferSelect;
export type InsertPatient = typeof patients.$inferInsert;

export const crmLeads = mysqlTable("crm_leads", {
  id: int("id").autoincrement().primaryKey(),
  leadCode: varchar("leadCode", { length: 32 }).notNull().unique(),
  patientId: int("patientId").notNull(),
  clinicId: int("clinicId"),
  appointmentId: int("appointmentId"),
  assignedEmployeeId: int("assignedEmployeeId"),
  treatmentInterest: varchar("treatmentInterest", { length: 180 }).notNull(),
  treatmentCategory: varchar("treatmentCategory", { length: 100 }),
  source: varchar("source", { length: 80 }).notNull().default("website"),
  pipeline: varchar("pipeline", { length: 80 }).notNull().default("patient-care"),
  stage: mysqlEnum("stage", ["new", "contacted", "evaluation", "quote_sent", "deposit_paid", "booked", "arrived", "treatment_completed", "follow_up"]).notNull().default("new"),
  priority: mysqlEnum("priority", ["low", "normal", "high", "urgent"]).notNull().default("normal"),
  notes: text("notes"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, table => ({
  stageIndex: index("crm_leads_stage_idx").on(table.stage, table.updatedAt),
  clinicIndex: index("crm_leads_clinic_idx").on(table.clinicId, table.updatedAt),
  patientIndex: index("crm_leads_patient_idx").on(table.patientId, table.updatedAt),
}));
export type CrmLead = typeof crmLeads.$inferSelect;
export type InsertCrmLead = typeof crmLeads.$inferInsert;

export const payments = mysqlTable("payments", {
  id: int("id").autoincrement().primaryKey(),
  paymentCode: varchar("paymentCode", { length: 32 }).notNull().unique(),
  patientId: int("patientId").notNull(),
  appointmentId: int("appointmentId"),
  leadId: int("leadId"),
  clinicId: int("clinicId"),
  amount: varchar("amount", { length: 32 }).notNull().default("0.00"),
  currency: varchar("currency", { length: 8 }).notNull().default("USD"),
  type: mysqlEnum("type", ["deposit", "full", "refund"]).notNull().default("deposit"),
  status: mysqlEnum("status", ["pending", "paid", "failed", "refunded"]).notNull().default("pending"),
  externalReference: varchar("externalReference", { length: 160 }),
  paidAt: timestamp("paidAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, table => ({
  patientIndex: index("payments_patient_idx").on(table.patientId, table.updatedAt),
  statusIndex: index("payments_status_idx").on(table.status, table.updatedAt),
  clinicIndex: index("payments_clinic_idx").on(table.clinicId, table.updatedAt),
}));
export type Payment = typeof payments.$inferSelect;
export type InsertPayment = typeof payments.$inferInsert;

export const careProviders = mysqlTable("care_providers", {
  id: int("id").autoincrement().primaryKey(),
  clinicId: int("clinicId"),
  userId: int("userId"),
  slug: varchar("slug", { length: 80 }).notNull().unique(),
  name: varchar("name", { length: 160 }).notNull(),
  specialty: varchar("specialty", { length: 160 }).notNull(),
  facility: varchar("facility", { length: 160 }).notNull(),
  bio: text("bio").notNull(),
  languages: varchar("languages", { length: 255 }).notNull(),
  timezone: varchar("timezone", { length: 80 }).notNull().default("UTC"),
  isActive: int("isActive").notNull().default(1),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type CareProvider = typeof careProviders.$inferSelect;
export type InsertCareProvider = typeof careProviders.$inferInsert;

export const appointments = mysqlTable(
  "appointments",
  {
    id: int("id").autoincrement().primaryKey(),
    patientUserId: int("patientUserId").notNull(),
    patientId: int("patientId"),
    providerId: int("providerId").notNull(),
    clinicId: int("clinicId"),
    leadId: int("leadId"),
    startsAt: timestamp("startsAt").notNull(),
    endsAt: timestamp("endsAt").notNull(),
    channel: mysqlEnum("channel", ["video", "phone", "in_person"]).notNull().default("video"),
    status: mysqlEnum("status", ["pending", "confirmed", "checked_in", "completed", "cancelled"]).notNull().default("pending"),
    treatmentName: varchar("treatmentName", { length: 180 }),
    patientName: varchar("patientName", { length: 180 }),
    patientPhone: varchar("patientPhone", { length: 40 }),
    patientEmail: varchar("patientEmail", { length: 320 }),
    patientCountry: varchar("patientCountry", { length: 100 }),
    reason: text("reason"),
    cancellationReason: text("cancellationReason"),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  table => ({
    providerSlotUnique: uniqueIndex("appointments_provider_slot_uq").on(table.providerId, table.startsAt),
    patientIndex: index("appointments_patient_idx").on(table.patientUserId, table.startsAt),
    clinicIndex: index("appointments_clinic_idx").on(table.clinicId, table.startsAt),
    leadIndex: index("appointments_lead_idx").on(table.leadId, table.updatedAt),
    statusIndex: index("appointments_status_idx").on(table.status, table.startsAt),
  })
);

export type Appointment = typeof appointments.$inferSelect;
export type InsertAppointment = typeof appointments.$inferInsert;

export const consultations = mysqlTable(
  "consultations",
  {
    id: int("id").autoincrement().primaryKey(),
    appointmentId: int("appointmentId").notNull(),
    clinicianUserId: int("clinicianUserId").notNull(),
    status: mysqlEnum("status", ["not_started", "in_progress", "completed"]).notNull().default("not_started"),
    patientSummary: text("patientSummary"),
    nextSteps: text("nextSteps"),
    internalNotes: text("internalNotes"),
    startedAt: timestamp("startedAt"),
    completedAt: timestamp("completedAt"),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  table => ({
    appointmentUnique: uniqueIndex("consultations_appointment_uq").on(table.appointmentId),
    appointmentIndex: index("consultations_appointment_idx").on(table.appointmentId),
  })
);

export type Consultation = typeof consultations.$inferSelect;
export type InsertConsultation = typeof consultations.$inferInsert;

export const notificationPreferences = mysqlTable(
  "notification_preferences",
  {
    id: int("id").autoincrement().primaryKey(),
    userId: int("userId").notNull(),
    phoneE164: varchar("phoneE164", { length: 32 }),
    emailOptIn: int("emailOptIn").notNull().default(1),
    smsOptIn: int("smsOptIn").notNull().default(0),
    staffReminderOptIn: int("staffReminderOptIn").notNull().default(1),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  table => ({
    userUnique: uniqueIndex("notification_preferences_user_uq").on(table.userId),
  })
);
export type NotificationPreferences = typeof notificationPreferences.$inferSelect;
export type InsertNotificationPreferences = typeof notificationPreferences.$inferInsert;

export const notificationDeliveries = mysqlTable(
  "notification_deliveries",
  {
    id: int("id").autoincrement().primaryKey(),
    appointmentId: int("appointmentId").notNull(),
    recipientUserId: int("recipientUserId").notNull(),
    channel: mysqlEnum("channel", ["email", "sms"]).notNull(),
    kind: mysqlEnum("kind", ["patient_24h", "patient_2h", "staff_24h", "staff_1h"]).notNull(),
    dedupeKey: varchar("dedupeKey", { length: 255 }).notNull(),
    recipient: varchar("recipient", { length: 320 }).notNull(),
    subject: varchar("subject", { length: 320 }),
    status: mysqlEnum("status", ["pending", "sending", "sent", "skipped", "failed"]).notNull().default("pending"),
    providerMessageId: varchar("providerMessageId", { length: 255 }),
    error: text("error"),
    sentAt: timestamp("sentAt"),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  table => ({
    dedupeUnique: uniqueIndex("notification_deliveries_dedupe_uq").on(table.dedupeKey),
    appointmentIndex: index("notification_deliveries_appointment_idx").on(table.appointmentId, table.createdAt),
    statusIndex: index("notification_deliveries_status_idx").on(table.status, table.updatedAt),
  })
);
export type NotificationDelivery = typeof notificationDeliveries.$inferSelect;
export type InsertNotificationDelivery = typeof notificationDeliveries.$inferInsert;

export const notificationSettings = mysqlTable("notification_settings", {
  id: int("id").primaryKey(),
  reminderTaskUid: varchar("reminderTaskUid", { length: 128 }),
  enabled: int("enabled").notNull().default(1),
  lastRunAt: timestamp("lastRunAt"),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});
export type NotificationSettings = typeof notificationSettings.$inferSelect;
export type InsertNotificationSettings = typeof notificationSettings.$inferInsert;
