CREATE TABLE `appointments` (
	`id` int AUTO_INCREMENT NOT NULL,
	`patientUserId` int NOT NULL,
	`providerId` int NOT NULL,
	`startsAt` timestamp NOT NULL,
	`endsAt` timestamp NOT NULL,
	`channel` enum('video','phone','in_person') NOT NULL DEFAULT 'video',
	`status` enum('pending','confirmed','checked_in','completed','cancelled') NOT NULL DEFAULT 'pending',
	`reason` text,
	`cancellationReason` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `appointments_id` PRIMARY KEY(`id`),
	CONSTRAINT `appointments_provider_slot_uq` UNIQUE(`providerId`,`startsAt`)
);
--> statement-breakpoint
CREATE TABLE `care_providers` (
	`id` int AUTO_INCREMENT NOT NULL,
	`slug` varchar(80) NOT NULL,
	`name` varchar(160) NOT NULL,
	`specialty` varchar(160) NOT NULL,
	`facility` varchar(160) NOT NULL,
	`bio` text NOT NULL,
	`languages` varchar(255) NOT NULL,
	`timezone` varchar(80) NOT NULL DEFAULT 'UTC',
	`isActive` int NOT NULL DEFAULT 1,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `care_providers_id` PRIMARY KEY(`id`),
	CONSTRAINT `care_providers_slug_unique` UNIQUE(`slug`)
);
--> statement-breakpoint
CREATE TABLE `consultations` (
	`id` int AUTO_INCREMENT NOT NULL,
	`appointmentId` int NOT NULL,
	`clinicianUserId` int NOT NULL,
	`status` enum('not_started','in_progress','completed') NOT NULL DEFAULT 'not_started',
	`patientSummary` text,
	`nextSteps` text,
	`internalNotes` text,
	`startedAt` timestamp,
	`completedAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `consultations_id` PRIMARY KEY(`id`),
	CONSTRAINT `consultations_appointment_uq` UNIQUE(`appointmentId`)
);
--> statement-breakpoint
CREATE INDEX `appointments_patient_idx` ON `appointments` (`patientUserId`,`startsAt`);--> statement-breakpoint
CREATE INDEX `appointments_status_idx` ON `appointments` (`status`,`startsAt`);--> statement-breakpoint
CREATE INDEX `consultations_appointment_idx` ON `consultations` (`appointmentId`);