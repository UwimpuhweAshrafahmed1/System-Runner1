CREATE TABLE `notification_deliveries` (
	`id` int AUTO_INCREMENT NOT NULL,
	`appointmentId` int NOT NULL,
	`recipientUserId` int NOT NULL,
	`channel` enum('email','sms') NOT NULL,
	`kind` enum('patient_24h','patient_2h','staff_24h','staff_1h') NOT NULL,
	`dedupeKey` varchar(255) NOT NULL,
	`recipient` varchar(320) NOT NULL,
	`subject` varchar(320),
	`status` enum('pending','sending','sent','skipped','failed') NOT NULL DEFAULT 'pending',
	`providerMessageId` varchar(255),
	`error` text,
	`sentAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `notification_deliveries_id` PRIMARY KEY(`id`),
	CONSTRAINT `notification_deliveries_dedupe_uq` UNIQUE(`dedupeKey`)
);
--> statement-breakpoint
CREATE TABLE `notification_preferences` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`phoneE164` varchar(32),
	`emailOptIn` int NOT NULL DEFAULT 1,
	`smsOptIn` int NOT NULL DEFAULT 0,
	`staffReminderOptIn` int NOT NULL DEFAULT 1,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `notification_preferences_id` PRIMARY KEY(`id`),
	CONSTRAINT `notification_preferences_user_uq` UNIQUE(`userId`)
);
--> statement-breakpoint
CREATE TABLE `notification_settings` (
	`id` int NOT NULL,
	`reminderTaskUid` varchar(128),
	`enabled` int NOT NULL DEFAULT 1,
	`lastRunAt` timestamp,
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `notification_settings_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE INDEX `notification_deliveries_appointment_idx` ON `notification_deliveries` (`appointmentId`,`createdAt`);--> statement-breakpoint
CREATE INDEX `notification_deliveries_status_idx` ON `notification_deliveries` (`status`,`updatedAt`);