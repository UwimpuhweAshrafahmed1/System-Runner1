CREATE TABLE `clinic_members` (
	`id` int AUTO_INCREMENT NOT NULL,
	`clinicId` int NOT NULL,
	`userId` int NOT NULL,
	`jobTitle` varchar(120),
	`isPrimary` int NOT NULL DEFAULT 0,
	`isActive` int NOT NULL DEFAULT 1,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `clinic_members_id` PRIMARY KEY(`id`),
	CONSTRAINT `clinic_members_clinic_user_uq` UNIQUE(`clinicId`,`userId`)
);
--> statement-breakpoint
CREATE TABLE `clinics` (
	`id` int AUTO_INCREMENT NOT NULL,
	`code` varchar(32) NOT NULL,
	`slug` varchar(100) NOT NULL,
	`name` varchar(180) NOT NULL,
	`country` varchar(100) NOT NULL,
	`city` varchar(100) NOT NULL,
	`timezone` varchar(80) NOT NULL DEFAULT 'UTC',
	`contactEmail` varchar(320),
	`phone` varchar(40),
	`isActive` int NOT NULL DEFAULT 1,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `clinics_id` PRIMARY KEY(`id`),
	CONSTRAINT `clinics_code_unique` UNIQUE(`code`),
	CONSTRAINT `clinics_slug_unique` UNIQUE(`slug`)
);
--> statement-breakpoint
CREATE TABLE `crm_leads` (
	`id` int AUTO_INCREMENT NOT NULL,
	`leadCode` varchar(32) NOT NULL,
	`patientId` int NOT NULL,
	`clinicId` int,
	`appointmentId` int,
	`assignedEmployeeId` int,
	`treatmentInterest` varchar(180) NOT NULL,
	`treatmentCategory` varchar(100),
	`source` varchar(80) NOT NULL DEFAULT 'website',
	`pipeline` varchar(80) NOT NULL DEFAULT 'patient-care',
	`stage` enum('new','contacted','evaluation','quote_sent','deposit_paid','booked','arrived','treatment_completed','follow_up') NOT NULL DEFAULT 'new',
	`priority` enum('low','normal','high','urgent') NOT NULL DEFAULT 'normal',
	`notes` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `crm_leads_id` PRIMARY KEY(`id`),
	CONSTRAINT `crm_leads_leadCode_unique` UNIQUE(`leadCode`)
);
--> statement-breakpoint
CREATE TABLE `patients` (
	`id` int AUTO_INCREMENT NOT NULL,
	`patientCode` varchar(32) NOT NULL,
	`userId` int NOT NULL,
	`firstName` varchar(100),
	`lastName` varchar(100),
	`phone` varchar(40),
	`email` varchar(320),
	`country` varchar(100),
	`language` varchar(80),
	`status` enum('new','active','follow_up','archived') NOT NULL DEFAULT 'new',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `patients_id` PRIMARY KEY(`id`),
	CONSTRAINT `patients_patientCode_unique` UNIQUE(`patientCode`),
	CONSTRAINT `patients_userId_unique` UNIQUE(`userId`)
);
--> statement-breakpoint
CREATE TABLE `payments` (
	`id` int AUTO_INCREMENT NOT NULL,
	`paymentCode` varchar(32) NOT NULL,
	`patientId` int NOT NULL,
	`appointmentId` int,
	`leadId` int,
	`clinicId` int,
	`amount` varchar(32) NOT NULL DEFAULT '0.00',
	`currency` varchar(8) NOT NULL DEFAULT 'USD',
	`type` enum('deposit','full','refund') NOT NULL DEFAULT 'deposit',
	`status` enum('pending','paid','failed','refunded') NOT NULL DEFAULT 'pending',
	`externalReference` varchar(160),
	`paidAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `payments_id` PRIMARY KEY(`id`),
	CONSTRAINT `payments_paymentCode_unique` UNIQUE(`paymentCode`)
);
--> statement-breakpoint
ALTER TABLE `appointments` ADD `patientId` int;--> statement-breakpoint
ALTER TABLE `appointments` ADD `clinicId` int;--> statement-breakpoint
ALTER TABLE `appointments` ADD `leadId` int;--> statement-breakpoint
ALTER TABLE `appointments` ADD `treatmentName` varchar(180);--> statement-breakpoint
ALTER TABLE `appointments` ADD `patientName` varchar(180);--> statement-breakpoint
ALTER TABLE `appointments` ADD `patientPhone` varchar(40);--> statement-breakpoint
ALTER TABLE `appointments` ADD `patientEmail` varchar(320);--> statement-breakpoint
ALTER TABLE `appointments` ADD `patientCountry` varchar(100);--> statement-breakpoint
ALTER TABLE `care_providers` ADD `clinicId` int;--> statement-breakpoint
ALTER TABLE `care_providers` ADD `userId` int;--> statement-breakpoint
ALTER TABLE `users` ADD `accountType` enum('patient','clinic','admin') DEFAULT 'patient' NOT NULL;--> statement-breakpoint
CREATE INDEX `clinic_members_user_idx` ON `clinic_members` (`userId`,`isActive`);--> statement-breakpoint
CREATE INDEX `crm_leads_stage_idx` ON `crm_leads` (`stage`,`updatedAt`);--> statement-breakpoint
CREATE INDEX `crm_leads_clinic_idx` ON `crm_leads` (`clinicId`,`updatedAt`);--> statement-breakpoint
CREATE INDEX `crm_leads_patient_idx` ON `crm_leads` (`patientId`,`updatedAt`);--> statement-breakpoint
CREATE INDEX `patients_status_idx` ON `patients` (`status`,`updatedAt`);--> statement-breakpoint
CREATE INDEX `payments_patient_idx` ON `payments` (`patientId`,`updatedAt`);--> statement-breakpoint
CREATE INDEX `payments_status_idx` ON `payments` (`status`,`updatedAt`);--> statement-breakpoint
CREATE INDEX `payments_clinic_idx` ON `payments` (`clinicId`,`updatedAt`);--> statement-breakpoint
CREATE INDEX `appointments_clinic_idx` ON `appointments` (`clinicId`,`startsAt`);--> statement-breakpoint
CREATE INDEX `appointments_lead_idx` ON `appointments` (`leadId`,`updatedAt`);