

## [ ] Four-role MediMATCH authentication and account routing
Add authoritative `patient` (Client), `clinic` (Employee), `partner` (Partner), and `admin` (CEO) account types to the existing authenticated user model; preserve legacy clinic/patient/admin records; provide a unified `/login` page with four selectable account entry points; route authenticated users to `/account`, `/employee`, `/partner`, or `/ceo` according to the database account type; enforce role and clinic tenancy server-side for every protected query and mutation; do not rely on hidden buttons for authorization.

## [ ] Phase 1 CRM-ready database schema
Persist `patients`, `clinics`, `clinic_members`, `care_providers` with optional clinic ownership, `crm_leads`, `appointments` with patient/clinic/lead/treatment/contact relationships, `consultations`, and `payments` with human-friendly codes, statuses, timestamps, and indexes. Preserve existing appointment/consultation data and relationships during migration.

## [ ] Phase 1 CRM-ready booking flow
Extend `/appointments` so booking captures treatment, provider/clinic or MediMATCH recommendation preference, date/time, patient name, phone, email, country, consultation channel, and high-level notes; server-side booking upserts the patient profile, creates or reuses a CRM lead, creates the appointment, links provider and clinic when selected, sets the lead stage, prevents duplicate active slots, and publishes live updates.

## [ ] Patient dashboard
Build `/account` as a patient-only dashboard with a friendly care journey, upcoming appointments, request/lead status, payment summary, and next actions; expose only the signed-in patient’s records and never show internal staff notes, commissions, internal pricing, employee conversations, internal tasks, other patients, or internal CRM analytics.

## [ ] Clinic dashboard
Build `/clinic` as a clinic-member-only tenant workspace with today’s appointment queue, incoming CRM leads, provider availability, appointment status controls, and clinic-scoped patient requests; prevent users from seeing records belonging to other clinics.

## [ ] MediMATCH admin dashboard
Build `/admin` as an admin-only network workspace with KPIs, lead pipeline, appointment queue, clinic/provider coverage, payment summary, assignment controls, and a link into the existing consultation desk; allow admin visibility across the MediMATCH network.

## [ ] Phase 1 validation and checkpoint
Run schema migration/seed, TypeScript checks, tests, production build, route-manifest verification, role/tenancy authorization checks, booking-to-lead persistence smoke tests, live event checks, and responsive visual review for login, patient, clinic, admin, and booking routes; commit the completed Phase 1 implementation to canonical `main`.

## [x] Protected partner CRM workspace procedure
Expose `crm.partnerWorkspace` through a server-side partner-only procedure; load the signed-in partner profile and active clinic/provider network from Managed MySQL; return only partner-safe network data without patient records or internal CRM details; reject unauthenticated and non-partner callers before querying partner data.
