import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { adminProcedure, clinicProcedure, isAdminAccount, patientProcedure, partnerProcedure, protectedProcedure, publicProcedure, router } from "./_core/trpc";
import { TRPCError } from "@trpc/server";
import { z } from "zod";
import {
  activeAppointmentStatuses,
  appointmentStatuses,
  ensureProviderCatalog,
  getAppointmentById,
  getDbOrThrow,
  getPatientAppointments,
  getStaffAppointments,
  isStaff,
  listAvailableSlots,
  publishAppointmentEvent,
  validateSlotDate,
} from "./appointments";
import { createOrReuseLead, ensurePatientProfile, getAdminWorkspace, getClinicWorkspace, getPartnerWorkspace, getPatientWorkspace, getUserClinicMemberships } from "./crm";
import { appointments, careProviders, consultations, crmLeads, type User } from "../drizzle/schema";
import { and, eq } from "drizzle-orm";
import { getNotificationPreferences, getNotificationSystemStatus, getRecentNotificationDeliveries, saveNotificationPreferences } from "./notifications";

const channelSchema = z.enum(["video", "phone", "in_person"]);
const consultationStatusSchema = z.enum(["not_started", "in_progress", "completed"]);

function invalidInput(message: string): never {
  throw new TRPCError({ code: "BAD_REQUEST", message });
}

async function assertClinicRecordAccess(user: User, clinicId: number | null) {
  if (isAdminAccount(user)) return;
  if (user.accountType !== "clinic" || !clinicId) throw new TRPCError({ code: "FORBIDDEN", message: "Clinic access is required for this record." });
  const memberships = await getUserClinicMemberships(user.id);
  if (!memberships.some(row => row.clinic.id === clinicId)) throw new TRPCError({ code: "FORBIDDEN", message: "You can only manage records for your clinic." });
}

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),

  care: router({
    providers: publicProcedure.query(async () => ensureProviderCatalog()),
    slots: publicProcedure
      .input(z.object({ providerId: z.number().int().positive(), from: z.string(), to: z.string() }))
      .query(async ({ input }) => {
        try {
          return await listAvailableSlots(input.providerId, input.from, input.to);
        } catch (error) {
          throw new TRPCError({ code: "BAD_REQUEST", message: error instanceof Error ? error.message : "Unable to load availability" });
        }
      }),
    mine: patientProcedure.query(async ({ ctx }) => {
      const rows = await getPatientAppointments(ctx.user.id);
      return rows.map(({ appointment, provider, consultation }) => ({
        appointment,
        provider,
        consultation: consultation ? {
          id: consultation.id,
          status: consultation.status,
          patientSummary: consultation.patientSummary,
          nextSteps: consultation.nextSteps,
          startedAt: consultation.startedAt,
          completedAt: consultation.completedAt,
        } : null,
      }));
    }),
    book: patientProcedure
      .input(z.object({
        providerId: z.number().int().positive(),
        startsAt: z.string().datetime(),
        channel: channelSchema,
        treatmentName: z.string().trim().min(2).max(180).default("Care consultation"),
        clinicId: z.number().int().positive().optional(),
        phone: z.string().trim().max(40).optional(),
        country: z.string().trim().max(100).optional(),
        reason: z.string().trim().min(2).max(1000).optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        const db = await getDbOrThrow();
        const [provider] = await db.select().from(careProviders).where(eq(careProviders.id, input.providerId)).limit(1);
        if (!provider || provider.isActive !== 1) throw new TRPCError({ code: "NOT_FOUND", message: "That care provider is not available." });
        if (provider.clinicId && input.clinicId && provider.clinicId !== input.clinicId) {
          throw new TRPCError({ code: "BAD_REQUEST", message: "The selected provider does not belong to that clinic." });
        }
        const startsAt = new Date(input.startsAt);
        if (startsAt <= new Date() || !validateSlotDate(startsAt)) invalidInput("Choose an available 30-minute weekday slot.");
        const endsAt = new Date(startsAt.getTime() + 30 * 60 * 1000);
        const patient = await ensurePatientProfile({ userId: ctx.user.id, name: ctx.user.name, email: ctx.user.email, phone: input.phone, country: input.country });
        const lead = await createOrReuseLead({ patientId: patient.id, clinicId: input.clinicId ?? provider.clinicId ?? null, treatmentInterest: input.treatmentName, source: "website-booking", notes: input.reason ?? null, stage: "booked" });
        const [existing] = await db.select().from(appointments).where(and(eq(appointments.providerId, input.providerId), eq(appointments.startsAt, startsAt))).limit(1);
        if (existing && activeAppointmentStatuses.includes(existing.status as (typeof activeAppointmentStatuses)[number])) {
          throw new TRPCError({ code: "CONFLICT", message: "That slot was just booked. Choose another time." });
        }
        let appointmentId: number;
        try {
          if (existing) {
            await db.update(appointments).set({ patientUserId: ctx.user.id, patientId: patient.id, clinicId: input.clinicId ?? provider.clinicId ?? null, leadId: lead.id, startsAt, endsAt, channel: input.channel, status: "pending", treatmentName: input.treatmentName, patientName: ctx.user.name ?? null, patientPhone: input.phone ?? patient.phone ?? null, patientEmail: ctx.user.email ?? patient.email ?? null, patientCountry: input.country ?? patient.country ?? null, reason: input.reason ?? null, cancellationReason: null, updatedAt: new Date() }).where(eq(appointments.id, existing.id));
            appointmentId = existing.id;
          } else {
            const result = await db.insert(appointments).values({ patientUserId: ctx.user.id, patientId: patient.id, providerId: input.providerId, clinicId: input.clinicId ?? provider.clinicId ?? null, leadId: lead.id, startsAt, endsAt, channel: input.channel, status: "pending", treatmentName: input.treatmentName, patientName: ctx.user.name ?? null, patientPhone: input.phone ?? patient.phone ?? null, patientEmail: ctx.user.email ?? patient.email ?? null, patientCountry: input.country ?? patient.country ?? null, reason: input.reason ?? null }).$returningId();
            appointmentId = result[0]?.id ?? 0;
          }
        } catch (error) {
          console.error("[Appointments] Booking conflict", error);
          throw new TRPCError({ code: "CONFLICT", message: "That slot is no longer available. Choose another time." });
        }
        await db.update(crmLeads).set({ appointmentId, stage: "booked", updatedAt: new Date() }).where(eq(crmLeads.id, lead.id));
        publishAppointmentEvent();
        return getAppointmentById(appointmentId);
      }),
    requestRecommendation: patientProcedure
      .input(z.object({ treatmentName: z.string().trim().min(2).max(180), clinicId: z.number().int().positive().optional(), phone: z.string().trim().max(40).optional(), country: z.string().trim().max(100).optional(), reason: z.string().trim().min(2).max(1000).optional() }))
      .mutation(async ({ ctx, input }) => {
        const patient = await ensurePatientProfile({ userId: ctx.user.id, name: ctx.user.name, email: ctx.user.email, phone: input.phone, country: input.country });
        const lead = await createOrReuseLead({ patientId: patient.id, clinicId: input.clinicId ?? null, treatmentInterest: input.treatmentName, source: "recommendation-request", notes: input.reason ?? null, stage: "new" });
        publishAppointmentEvent();
        return { leadCode: lead.leadCode, stage: lead.stage };
      }),
    cancel: patientProcedure
      .input(z.object({ appointmentId: z.number().int().positive(), reason: z.string().trim().max(500).optional() }))
      .mutation(async ({ ctx, input }) => {
        const record = await getAppointmentById(input.appointmentId);
        if (!record) throw new TRPCError({ code: "NOT_FOUND", message: "Appointment not found." });
        if (!isStaff(ctx.user) && record.appointment.patientUserId !== ctx.user.id) throw new TRPCError({ code: "FORBIDDEN", message: "You can only manage your own appointments." });
        if (!activeAppointmentStatuses.includes(record.appointment.status as (typeof activeAppointmentStatuses)[number])) throw new TRPCError({ code: "BAD_REQUEST", message: "This appointment can no longer be cancelled." });
        const db = await getDbOrThrow();
        await db.update(appointments).set({ status: "cancelled", cancellationReason: input.reason ?? null, updatedAt: new Date() }).where(eq(appointments.id, input.appointmentId));
        publishAppointmentEvent();
        return { success: true } as const;
      }),
    detail: protectedProcedure
      .input(z.object({ appointmentId: z.number().int().positive() }))
      .query(async ({ ctx, input }) => {
        const record = await getAppointmentById(input.appointmentId);
        if (!record) throw new TRPCError({ code: "NOT_FOUND", message: "Appointment not found." });
        if (!isStaff(ctx.user) && record.appointment.patientUserId !== ctx.user.id) throw new TRPCError({ code: "FORBIDDEN", message: "You can only view your own appointments." });
        if (isStaff(ctx.user)) return record;
        return { ...record, consultation: record.consultation ? { ...record.consultation, internalNotes: null } : null };
      }),
    staffQueue: adminProcedure.query(async () => getStaffAppointments()),
    updateStatus: protectedProcedure
      .input(z.object({ appointmentId: z.number().int().positive(), status: z.enum(appointmentStatuses), cancellationReason: z.string().trim().max(500).optional() }))
      .mutation(async ({ ctx, input }) => {
        const db = await getDbOrThrow();
        const [appointment] = await db.select().from(appointments).where(eq(appointments.id, input.appointmentId)).limit(1);
        if (!appointment) throw new TRPCError({ code: "NOT_FOUND", message: "Appointment not found." });
        await assertClinicRecordAccess(ctx.user, appointment.clinicId);
        await db.update(appointments).set({ status: input.status, cancellationReason: input.status === "cancelled" ? input.cancellationReason ?? null : null, updatedAt: new Date() }).where(eq(appointments.id, input.appointmentId));
        publishAppointmentEvent();
        return { success: true } as const;
      }),
    saveConsultation: protectedProcedure
      .input(z.object({
        appointmentId: z.number().int().positive(),
        status: consultationStatusSchema,
        patientSummary: z.string().trim().max(4000).optional(),
        nextSteps: z.string().trim().max(2000).optional(),
        internalNotes: z.string().trim().max(4000).optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        const db = await getDbOrThrow();
        const record = await getAppointmentById(input.appointmentId);
        if (!record) throw new TRPCError({ code: "NOT_FOUND", message: "Appointment not found." });
        await assertClinicRecordAccess(ctx.user, record.appointment.clinicId);
        const now = new Date();
        const existing = record.consultation;
        const startedAt = input.status === "not_started" ? existing?.startedAt ?? null : existing?.startedAt ?? now;
        const completedAt = input.status === "completed" ? existing?.completedAt ?? now : null;
        if (existing) {
          await db.update(consultations).set({ clinicianUserId: ctx.user.id, status: input.status, patientSummary: input.patientSummary ?? null, nextSteps: input.nextSteps ?? null, internalNotes: input.internalNotes ?? null, startedAt, completedAt, updatedAt: now }).where(eq(consultations.id, existing.id));
        } else {
          await db.insert(consultations).values({ appointmentId: input.appointmentId, clinicianUserId: ctx.user.id, status: input.status, patientSummary: input.patientSummary ?? null, nextSteps: input.nextSteps ?? null, internalNotes: input.internalNotes ?? null, startedAt, completedAt });
        }
        if (input.status === "completed") {
          await db.update(appointments).set({ status: "completed", updatedAt: now }).where(eq(appointments.id, input.appointmentId));
        } else if (input.status === "in_progress") {
          await db.update(appointments).set({ status: "checked_in", updatedAt: now }).where(eq(appointments.id, input.appointmentId));
        }
        publishAppointmentEvent();
        return { success: true } as const;
      }),
  }),

  crm: router({
    patientWorkspace: patientProcedure.query(({ ctx }) => getPatientWorkspace(ctx.user.id)),
    clinicWorkspace: clinicProcedure.query(({ ctx }) => getClinicWorkspace(ctx.user.id)),
    partnerWorkspace: partnerProcedure.query(({ ctx }) => getPartnerWorkspace(ctx.user.id)),
    adminWorkspace: adminProcedure.query(() => getAdminWorkspace()),
    updateLeadStage: protectedProcedure
      .input(z.object({ leadId: z.number().int().positive(), stage: z.enum(["new", "contacted", "evaluation", "quote_sent", "deposit_paid", "booked", "arrived", "treatment_completed", "follow_up"]) }))
      .mutation(async ({ ctx, input }) => {
        const db = await getDbOrThrow();
        const [lead] = await db.select().from(crmLeads).where(eq(crmLeads.id, input.leadId)).limit(1);
        if (!lead) throw new TRPCError({ code: "NOT_FOUND", message: "CRM lead not found." });
        await assertClinicRecordAccess(ctx.user, lead.clinicId);
        await db.update(crmLeads).set({ stage: input.stage, updatedAt: new Date() }).where(eq(crmLeads.id, input.leadId));
        publishAppointmentEvent();
        return { success: true } as const;
      }),
  }),

  notifications: router({
    preferences: protectedProcedure.query(({ ctx }) => getNotificationPreferences(ctx.user.id)),
    savePreferences: protectedProcedure
      .input(z.object({
        phoneE164: z.string().trim().regex(/^\+[1-9]\d{7,14}$/, "Use an international phone number, for example +447700900123.").nullable(),
        emailOptIn: z.boolean(),
        smsOptIn: z.boolean(),
        staffReminderOptIn: z.boolean().default(true),
      }))
      .mutation(async ({ ctx, input }) => {
        if (input.smsOptIn && !input.phoneE164) {
          throw new TRPCError({ code: "BAD_REQUEST", message: "Add an international phone number before enabling SMS reminders." });
        }
        return saveNotificationPreferences({ userId: ctx.user.id, ...input });
      }),
    status: adminProcedure.query(() => getNotificationSystemStatus()),
    recent: adminProcedure.query(() => getRecentNotificationDeliveries()),
  }),
});

export type AppRouter = typeof appRouter;
