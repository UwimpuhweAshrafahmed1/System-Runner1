import { and, asc, desc, eq, inArray, ne } from "drizzle-orm";
import { appointments, careProviders, clinicMembers, clinics, crmLeads, patients, payments, users } from "../drizzle/schema";
import { getDb } from "./db";

function splitName(value: string | null | undefined) {
  const normalized = (value ?? "").trim();
  if (!normalized) return { firstName: null, lastName: null };
  const [firstName, ...rest] = normalized.split(/\s+/);
  return { firstName, lastName: rest.join(" ") || null };
}

function code(prefix: string, id: number) {
  return `MM-${prefix}-${String(id).padStart(6, "0")}`;
}

function leadCode() {
  return `MM-L-${Date.now().toString().slice(-8)}`;
}

export async function ensurePatientProfile(input: {
  userId: number;
  name?: string | null;
  email?: string | null;
  phone?: string | null;
  country?: string | null;
  language?: string | null;
}) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const [existing] = await db.select().from(patients).where(eq(patients.userId, input.userId)).limit(1);
  const names = splitName(input.name);
  if (existing) {
    await db.update(patients).set({
      firstName: names.firstName ?? existing.firstName,
      lastName: names.lastName ?? existing.lastName,
      email: input.email ?? existing.email,
      phone: input.phone ?? existing.phone,
      country: input.country ?? existing.country,
      language: input.language ?? existing.language,
      status: existing.status === "new" ? "active" : existing.status,
      updatedAt: new Date(),
    }).where(eq(patients.id, existing.id));
    const [updated] = await db.select().from(patients).where(eq(patients.id, existing.id)).limit(1);
    return updated ?? existing;
  }
  const provisionalCode = code("P", input.userId);
  await db.insert(patients).values({
    patientCode: provisionalCode,
    userId: input.userId,
    firstName: names.firstName,
    lastName: names.lastName,
    email: input.email ?? null,
    phone: input.phone ?? null,
    country: input.country ?? null,
    language: input.language ?? null,
    status: "active",
  });
  const [created] = await db.select().from(patients).where(eq(patients.userId, input.userId)).limit(1);
  if (!created) throw new Error("Patient profile could not be created");
  return created;
}

export async function getUserClinicMemberships(userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  return db.select({ clinic: clinics, membership: clinicMembers })
    .from(clinicMembers)
    .innerJoin(clinics, eq(clinics.id, clinicMembers.clinicId))
    .where(and(eq(clinicMembers.userId, userId), eq(clinicMembers.isActive, 1), eq(clinics.isActive, 1)))
    .orderBy(asc(clinics.name));
}

export async function createOrReuseLead(input: {
  patientId: number;
  clinicId?: number | null;
  treatmentInterest: string;
  treatmentCategory?: string | null;
  source?: string;
  notes?: string | null;
  stage?: "new" | "contacted" | "evaluation" | "quote_sent" | "deposit_paid" | "booked" | "arrived" | "treatment_completed" | "follow_up";
}) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const [existing] = await db.select().from(crmLeads)
    .where(and(eq(crmLeads.patientId, input.patientId), eq(crmLeads.treatmentInterest, input.treatmentInterest), ne(crmLeads.stage, "treatment_completed")))
    .orderBy(desc(crmLeads.updatedAt))
    .limit(1);
  if (existing) {
    await db.update(crmLeads).set({
      clinicId: input.clinicId ?? existing.clinicId,
      treatmentCategory: input.treatmentCategory ?? existing.treatmentCategory,
      notes: input.notes ?? existing.notes,
      source: input.source ?? existing.source,
      stage: input.stage ?? existing.stage,
      updatedAt: new Date(),
    }).where(eq(crmLeads.id, existing.id));
    const [updated] = await db.select().from(crmLeads).where(eq(crmLeads.id, existing.id)).limit(1);
    return updated ?? existing;
  }
  await db.insert(crmLeads).values({
    leadCode: leadCode(),
    patientId: input.patientId,
    clinicId: input.clinicId ?? null,
    treatmentInterest: input.treatmentInterest,
    treatmentCategory: input.treatmentCategory ?? null,
    source: input.source ?? "website",
    stage: input.stage ?? "new",
    notes: input.notes ?? null,
  });
  const [created] = await db.select().from(crmLeads)
    .where(and(eq(crmLeads.patientId, input.patientId), eq(crmLeads.treatmentInterest, input.treatmentInterest)))
    .orderBy(desc(crmLeads.createdAt)).limit(1);
  if (!created) throw new Error("CRM lead could not be created");
  return created;
}

export async function getPatientWorkspace(userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const [patient] = await db.select().from(patients).where(eq(patients.userId, userId)).limit(1);
  if (!patient) return { patient: null, leads: [], appointments: [], payments: [] };
  const [leadRows, appointmentRows, paymentRows] = await Promise.all([
    db.select().from(crmLeads).where(eq(crmLeads.patientId, patient.id)).orderBy(desc(crmLeads.updatedAt)).limit(20),
    db.select({ appointment: appointments, provider: careProviders, clinic: clinics })
      .from(appointments)
      .leftJoin(careProviders, eq(careProviders.id, appointments.providerId))
      .leftJoin(clinics, eq(clinics.id, appointments.clinicId))
      .where(eq(appointments.patientId, patient.id))
      .orderBy(desc(appointments.startsAt)).limit(20),
    db.select().from(payments).where(eq(payments.patientId, patient.id)).orderBy(desc(payments.updatedAt)).limit(20),
  ]);
  return { patient, leads: leadRows, appointments: appointmentRows, payments: paymentRows };
}

export async function getClinicWorkspace(userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const memberships = await getUserClinicMemberships(userId);
  const clinicIds = memberships.map(row => row.clinic.id);
  if (!clinicIds.length) return { memberships, clinics: [], providers: [], leads: [], appointments: [] };
  const [providers, leads, appointmentRows] = await Promise.all([
    db.select().from(careProviders).where(and(inArray(careProviders.clinicId, clinicIds), eq(careProviders.isActive, 1))).orderBy(asc(careProviders.name)),
    db.select({ lead: crmLeads, patient: patients })
      .from(crmLeads)
      .innerJoin(patients, eq(patients.id, crmLeads.patientId))
      .where(inArray(crmLeads.clinicId, clinicIds)).orderBy(desc(crmLeads.updatedAt)).limit(50),
    db.select({ appointment: appointments, patient: patients, provider: careProviders, clinic: clinics, lead: crmLeads })
      .from(appointments)
      .innerJoin(patients, eq(patients.id, appointments.patientId))
      .leftJoin(careProviders, eq(careProviders.id, appointments.providerId))
      .leftJoin(clinics, eq(clinics.id, appointments.clinicId))
      .leftJoin(crmLeads, eq(crmLeads.id, appointments.leadId))
      .where(inArray(appointments.clinicId, clinicIds)).orderBy(asc(appointments.startsAt)).limit(100),
  ]);
  return { memberships, clinics: memberships.map(row => row.clinic), providers, leads, appointments: appointmentRows };
}

export async function getPartnerWorkspace(userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const [partner] = await db.select({
    id: users.id,
    name: users.name,
    email: users.email,
    role: users.role,
    accountType: users.accountType,
    createdAt: users.createdAt,
    lastSignedIn: users.lastSignedIn,
  }).from(users).where(eq(users.id, userId)).limit(1);
  if (!partner || partner.accountType !== "partner") throw new Error("Partner account could not be found");
  const [clinicRows, providerRows] = await Promise.all([
    db.select({
      id: clinics.id,
      code: clinics.code,
      slug: clinics.slug,
      name: clinics.name,
      country: clinics.country,
      city: clinics.city,
      timezone: clinics.timezone,
    }).from(clinics).where(eq(clinics.isActive, 1)).orderBy(asc(clinics.name)),
    db.select({
      id: careProviders.id,
      clinicId: careProviders.clinicId,
      slug: careProviders.slug,
      name: careProviders.name,
      specialty: careProviders.specialty,
      facility: careProviders.facility,
      languages: careProviders.languages,
      timezone: careProviders.timezone,
    }).from(careProviders).where(eq(careProviders.isActive, 1)).orderBy(asc(careProviders.name)),
  ]);
  return {
    partner,
    clinics: clinicRows,
    providers: providerRows,
    stats: {
      activeClinics: clinicRows.length,
      activeProviders: providerRows.length,
      availableSpecialties: new Set(providerRows.map(provider => provider.specialty)).size,
    },
  };
}

export async function getAdminWorkspace() {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const [patientsCount, clinicsCount, providers, leads, appointmentRows, paymentRows] = await Promise.all([
    db.select({ id: patients.id }).from(patients),
    db.select({ id: clinics.id }).from(clinics).where(eq(clinics.isActive, 1)),
    db.select().from(careProviders).where(eq(careProviders.isActive, 1)).orderBy(asc(careProviders.name)),
    db.select({ lead: crmLeads, patient: patients, clinic: clinics })
      .from(crmLeads)
      .innerJoin(patients, eq(patients.id, crmLeads.patientId))
      .leftJoin(clinics, eq(clinics.id, crmLeads.clinicId))
      .orderBy(desc(crmLeads.updatedAt)).limit(100),
    db.select({ appointment: appointments, patient: patients, provider: careProviders, clinic: clinics, lead: crmLeads })
      .from(appointments)
      .innerJoin(patients, eq(patients.id, appointments.patientId))
      .leftJoin(careProviders, eq(careProviders.id, appointments.providerId))
      .leftJoin(clinics, eq(clinics.id, appointments.clinicId))
      .leftJoin(crmLeads, eq(crmLeads.id, appointments.leadId))
      .orderBy(desc(appointments.updatedAt)).limit(100),
    db.select().from(payments).orderBy(desc(payments.updatedAt)).limit(100),
  ]);
  return { patients: patientsCount.length, clinics: clinicsCount.length, providers, leads, appointments: appointmentRows, payments: paymentRows };
}
