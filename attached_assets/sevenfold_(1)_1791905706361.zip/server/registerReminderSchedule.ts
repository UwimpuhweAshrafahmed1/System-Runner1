import "dotenv/config";
import { createHeartbeatJob } from "./_core/heartbeat";
import { saveReminderTaskUid } from "./notifications";

const schedule = await createHeartbeatJob({
  name: "MediMATCH appointment reminders",
  cron: "0 */5 * * * *",
  path: "/api/scheduled/appointment-reminders",
  method: "POST",
  description: "Every five minutes, send idempotent patient and staff reminders for appointments approaching in the next 24 hours.",
}, "");

await saveReminderTaskUid(schedule.taskUid);
console.log(JSON.stringify({ taskUid: schedule.taskUid, nextExecutionAt: schedule.nextExecutionAt ?? null }));
