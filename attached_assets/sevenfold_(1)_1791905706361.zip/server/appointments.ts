import { and, asc, desc, eq, gte, inArray, lt } from "drizzle-orm";
import type { User } from "../drizzle/schema";
import { appointments, careProviders, consultations, users } from "../drizzle/schema";
import { getDb } from "./db";

export const appointmentStatuses = ["pending", "confirmed", "checked_in", "completed", "cancelled"] as const;
export type AppointmentStatus = (typeof appointmentStatuses)[number];
export const activeAppointmentStatuses = ["pending", "confirmed", "checked_in"] as const;

export type AppointmentEvent = {
  type: "appointments.changed";
  at: string;
};

const subscribers = new Set<(event: AppointmentEvent) => void>();

export function subscribeToAppointmentEvents(listener: (event: AppointmentEvent) => void) {
  subscribers.add(listener);
  return () => subscribers.delete(listener);
}

export function publishAppointmentEvent() {
  const event: AppointmentEvent = { type: "appointments.changed", at: new Date().toISOString() };
  for (const listener of subscribers) listener(event);
}

export function isStaff(user: User | null | undefined) {
  return user?.accountType === "admin" || user?.role === "admin";
}

const providerSeed = [
  {
    slug: "dr-amara-okafor",
    name: "Dr. Amara Okafor",
    specialty: "Internal medicine",
    facility: "MediMATCH London Care Centre",
    bio: "Calm, evidence-led consultations for complex symptoms, ongoing care, and second opinions.",
    languages: "English · French · Igbo",
    timezone: "UTC",
  },
  {
    slug: "dr-luca-moretti",
    name: "Dr. Luca Moretti",
    specialty: "Orthopaedics",
    facility: "MediMATCH Milan Partner Clinic",
    bio: "Movement-focused assessments and recovery planning for everyday mobility and sports injuries.",
    languages: "English · Italian · Spanish",
    timezone: "UTC",
  },
  {
    slug: "dr-sarah-chen",
    name: "Dr. Sarah Chen",
    specialty: "Dermatology",
    facility: "MediMATCH Singapore Care Studio",
    bio: "Thoughtful skin consultations, treatment planning, and clear next steps for long-term confidence.",
    languages: "English · Mandarin · Cantonese",
    timezone: "UTC",
  },
] as const;

function parseDateKey(dateKey: string) {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(dateKey)) throw new Error("Date must use YYYY-MM-DD");
  const [year, month, day] = dateKey.split("-").map(Number);
  const date = new Date(Date.UTC(year, month - 1, day));
  if (Number.isNaN(date.getTime()) || date.getUTCFullYear() !== year || date.getUTCMonth() !== month - 1 || date.getUTCDate() !== day) {
    throw new Error("Invalid date");
  }
  return date;
}

export function dateKey(date: Date) {
  return date.toISOString().slice(0, 10);
}

function addDays(date: Date, days: number) {
  const next = new Date(date);
  next.setUTCDate(next.getUTCDate() + days);
  return next;
}

export function candidateSlotsForDate(dateKeyValue: string) {
  const day = parseDateKey(dateKeyValue);
  const weekday = day.getUTCDay();
  if (weekday === 0 || weekday === 6) return [] as Date[];
  const slots: Date[] = [];
  for (let hour = 9; hour < 17; hour += 1) {
    for (const minute of [0, 30]) slots.push(new Date(Date.UTC(day.getUTCFullYear(), day.getUTCMonth(), day.getUTCDate(), hour, minute)));
  }
  return slots;
}

export function validateSlotDate(startsAt: Date) {
  const candidate = candidateSlotsForDate(dateKey(startsAt));
  return candidate.some(slot => slot.getTime() === startsAt.getTime());
}

export async function ensureProviderCatalog() {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const existing = await db.select({ id: careProviders.id }).from(careProviders).limit(1);
  if (existing.length === 0) {
    await db.insert(careProviders).values(providerSeed.map(provider => ({ ...provider, isActive: 1 })));
  }
  return db.select().from(careProviders).where(eq(careProviders.isActive, 1)).orderBy(asc(careProviders.name));
}

export async function listAvailableSlots(providerId: number, from: string, to: string) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const start = parseDateKey(from);
  const end = parseDateKey(to);
  if (end < start) throw new Error("The end date must be after the start date");
  if (addDays(start, 14) < end) throw new Error("Availability windows are limited to 14 days");
  const booked = await db.select({ startsAt: appointments.startsAt }).from(appointments).where(and(
    eq(appointments.providerId, providerId),
    gte(appointments.startsAt, start),
    lt(appointments.startsAt, addDays(end, 1)),
    inArray(appointments.status, activeAppointmentStatuses)
  ));
  const busy = new Set(booked.map(row => row.startsAt.toISOString()));
  const days: Array<{ date: string; slots: string[] }> = [];
  for (let cursor = start; cursor <= end; cursor = addDays(cursor, 1)) {
    const key = dateKey(cursor);
    days.push({ date: key, slots: candidateSlotsForDate(key).filter(slot => !busy.has(slot.toISOString())).map(slot => slot.toISOString()) });
  }
  return days;
}

export async function getPatientAppointments(patientUserId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  return db.select({ appointment: appointments, provider: careProviders, consultation: consultations })
    .from(appointments)
    .innerJoin(careProviders, eq(appointments.providerId, careProviders.id))
    .leftJoin(consultations, eq(consultations.appointmentId, appointments.id))
    .where(eq(appointments.patientUserId, patientUserId))
    .orderBy(desc(appointments.startsAt));
}

export async function getStaffAppointments() {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  return db.select({ appointment: appointments, provider: careProviders, patient: users, consultation: consultations })
    .from(appointments)
    .innerJoin(careProviders, eq(appointments.providerId, careProviders.id))
    .innerJoin(users, eq(appointments.patientUserId, users.id))
    .leftJoin(consultations, eq(consultations.appointmentId, appointments.id))
    .orderBy(asc(appointments.startsAt));
}

export async function getAppointmentById(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const [row] = await db.select({ appointment: appointments, provider: careProviders, patient: users, consultation: consultations })
    .from(appointments)
    .innerJoin(careProviders, eq(appointments.providerId, careProviders.id))
    .innerJoin(users, eq(appointments.patientUserId, users.id))
    .leftJoin(consultations, eq(consultations.appointmentId, appointments.id))
    .where(eq(appointments.id, id))
    .limit(1);
  return row;
}

export async function getDbOrThrow() {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  return db;
}
