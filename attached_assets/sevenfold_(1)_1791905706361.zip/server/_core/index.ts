import "dotenv/config";
import express from "express";
import { createServer } from "http";
import { createExpressMiddleware } from "@trpc/server/adapters/express";
import { registerOAuthRoutes } from "./oauth";
import { publicPlatformScript } from "./publicConfig";
import { appRouter } from "../routers";
import { createContext } from "./context";
import { serveStatic, setupVite } from "./vite";
import { subscribeToAppointmentEvents } from "../appointments";
import { sdk } from "./sdk";
import { getReminderSettings, runAppointmentReminderSweep } from "../notifications";

async function startServer() {
  const app = express();
  const server = createServer(app);
  // Configure body parser with larger size limit for file uploads
  app.use(express.json({ limit: "50mb" }));
  app.use(express.urlencoded({ limit: "50mb", extended: true }));
  app.get("/api/health", (_req, res) => res.json({ status: "ok" }));
  app.get("/api/platform/config.js", (_req, res) => {
    res.set("Cache-Control", "no-store").type("application/javascript").send(publicPlatformScript());
  });
  app.get("/api/appointments/events", async (req, res) => {
    try {
      await sdk.authenticateRequest(req);
    } catch {
      res.status(401).json({ message: "Authentication required" });
      return;
    }
    res.status(200).set({
      "Content-Type": "text/event-stream",
      "Cache-Control": "no-cache, no-transform",
      Connection: "keep-alive",
      "X-Accel-Buffering": "no",
    });
    res.flushHeaders();
    res.write(`event: ready\ndata: ${JSON.stringify({ at: new Date().toISOString() })}\n\n`);
    const unsubscribe = subscribeToAppointmentEvents(event => {
      if (!res.writableEnded) res.write(`event: appointments.changed\ndata: ${JSON.stringify(event)}\n\n`);
    });
    const heartbeat = setInterval(() => {
      if (!res.writableEnded) res.write(": keepalive\n\n");
    }, 25_000);
    const cleanup = () => {
      clearInterval(heartbeat);
      unsubscribe();
    };
    req.on("close", cleanup);
    res.on("close", cleanup);
  });
  app.post("/api/scheduled/appointment-reminders", async (req, res) => {
    let cronUser;
    try {
      cronUser = await sdk.authenticateRequest(req);
    } catch {
      res.status(401).json({ ok: false, message: "Scheduled task authentication required" });
      return;
    }
    if (!cronUser.isCron || !cronUser.taskUid) {
      res.status(403).json({ ok: false, message: "Only the registered MediMATCH reminder task may run this callback" });
      return;
    }
    const settings = await getReminderSettings();
    if (!settings?.reminderTaskUid || settings.reminderTaskUid !== cronUser.taskUid) {
      res.status(503).json({ ok: false, message: "Reminder schedule is not registered for this project" });
      return;
    }
    if (settings.enabled === 0) {
      res.json({ ok: true, skipped: "disabled" });
      return;
    }
    try {
      const result = await runAppointmentReminderSweep(new Date());
      res.json({ ok: true, ...result });
    } catch (error) {
      console.error("[Notifications] Reminder sweep failed", error);
      res.status(500).json({ ok: false, message: error instanceof Error ? error.message : "Reminder sweep failed" });
    }
  });
  registerOAuthRoutes(app);
  // tRPC API
  app.use(
    "/api/trpc",
    createExpressMiddleware({
      router: appRouter,
      createContext,
    })
  );
  // development mode uses Vite, production mode uses static files
  if (process.env.NODE_ENV === "development") {
    await setupVite(app, server);
  } else {
    serveStatic(app);
  }

  const port = Number(process.env.PORT || "3000");
  if (!Number.isInteger(port) || port < 1 || port > 65535) throw new Error("Invalid PORT");
  server.on("error", error => { console.error("Server failed:", error.message); process.exit(1); });
  server.listen(port, "0.0.0.0", () => console.log(`Server listening on port ${port}`));
}

startServer().catch(error => { console.error(error); process.exit(1); });
