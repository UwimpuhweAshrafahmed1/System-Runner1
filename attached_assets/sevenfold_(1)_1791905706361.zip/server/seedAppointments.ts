import "dotenv/config";
import { eq, sql } from "drizzle-orm";
import { careProviders, clinics } from "../drizzle/schema";
import { ensureProviderCatalog } from "./appointments";
import { getDb } from "./db";

const clinicSeed = [
  { code: "MM-CL-LON", slug: "london-care-centre", name: "MediMATCH London Care Centre", country: "United Kingdom", city: "London", timezone: "Europe/London", contactEmail: "london@medimatch.health", phone: "+442000000001" },
  { code: "MM-CL-MIL", slug: "milan-partner-clinic", name: "MediMATCH Milan Partner Clinic", country: "Italy", city: "Milan", timezone: "Europe/Rome", contactEmail: "milan@medimatch.health", phone: "+390200000002" },
  { code: "MM-CL-SIN", slug: "singapore-care-studio", name: "MediMATCH Singapore Care Studio", country: "Singapore", city: "Singapore", timezone: "Asia/Singapore", contactEmail: "singapore@medimatch.health", phone: "+65600000003" },
] as const;

async function main() {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db.execute(sql`UPDATE users SET accountType = CASE WHEN role = 'admin' THEN 'admin' WHEN accountType IN ('clinic', 'partner') THEN accountType ELSE 'patient' END`);
  const providers = await ensureProviderCatalog();
  for (const clinic of clinicSeed) {
    await db.insert(clinics).values(clinic).onDuplicateKeyUpdate({ set: { name: clinic.name, country: clinic.country, city: clinic.city, timezone: clinic.timezone, contactEmail: clinic.contactEmail, phone: clinic.phone, isActive: 1 } });
  }
  const clinicRows = await db.select().from(clinics);
  const clinicBySlug = new Map(clinicRows.map(clinic => [clinic.slug, clinic.id]));
  const providerClinicMap: Record<string, string> = {
    "dr-amara-okafor": "london-care-centre",
    "dr-luca-moretti": "milan-partner-clinic",
    "dr-sarah-chen": "singapore-care-studio",
  };
  for (const provider of providers) {
    const clinicId = clinicBySlug.get(providerClinicMap[provider.slug]);
    if (clinicId) await db.update(careProviders).set({ clinicId, updatedAt: new Date() }).where(eq(careProviders.id, provider.id));
  }
  console.log(`[MediMATCH] Phase 1 seed ready: ${providers.length} providers, ${clinicRows.length} clinics`);
  process.exit(0);
}

main().catch(error => {
  console.error("[MediMATCH] Phase 1 seed failed", error);
  process.exit(1);
});
