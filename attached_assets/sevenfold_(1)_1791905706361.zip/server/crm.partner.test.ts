import { describe, expect, it } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

type AccountType = "patient" | "clinic" | "partner" | "admin";

type TestUser = NonNullable<TrpcContext["user"]>;

function createUser(accountType: AccountType): TestUser {
  return {
    id: 42,
    openId: `partner-test-${accountType}`,
    email: `${accountType}@example.com`,
    name: "MediMATCH Test Account",
    loginMethod: "test",
    role: accountType === "admin" ? "admin" : "user",
    accountType,
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
  };
}

function createContext(user: TrpcContext["user"]): TrpcContext {
  return {
    user,
    req: { protocol: "https", headers: {} } as TrpcContext["req"],
    res: {} as TrpcContext["res"],
  };
}

describe("crm.partnerWorkspace", () => {
  it("requires an authenticated session", async () => {
    const caller = appRouter.createCaller(createContext(null));
    await expect(caller.crm.partnerWorkspace()).rejects.toMatchObject({ code: "UNAUTHORIZED" });
  });

  it("rejects non-partner accounts before touching partner data", async () => {
    const caller = appRouter.createCaller(createContext(createUser("clinic")));
    await expect(caller.crm.partnerWorkspace()).rejects.toMatchObject({ code: "FORBIDDEN" });
  });
});
