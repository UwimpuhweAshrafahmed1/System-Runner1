import { and, asc, desc, eq, gte, inArray, lt, or } from "drizzle-orm";
import {
  appointments,
  careProviders,
  notificationDeliveries,
  notificationPreferences,
  notificationSettings,
  users,
} from "../drizzle/schema";
import { getDb } from "./db";

export const notificationKinds = ["patient_24h", "patient_2h", "staff_24h", "staff_1h"] as const;
export type NotificationKind = (typeof notificationKinds)[number];
export type NotificationChannel = "email" | "sms";

const activeStatuses = ["pending", "confirmed", "checked_in"] as const;
const REMINDER_WINDOWS: Array<{ kind: NotificationKind; minHours: number; maxHours: number }> = [
  { kind: "patient_24h", minHours: 23.75, maxHours: 24.25 },
  { kind: "patient_2h", minHours: 1.75, maxHours: 2.25 },
  { kind: "staff_24h", minHours: 23.75, maxHours: 24.25 },
  { kind: "staff_1h", minHours: 0.75, maxHours: 1.25 },
];

function hasEmailProvider() {
  return Boolean(process.env.RESEND_API_KEY && process.env.RESEND_FROM_EMAIL);
}

function hasSmsProvider() {
  return Boolean(process.env.TWILIO_ACCOUNT_SID && process.env.TWILIO_AUTH_TOKEN && process.env.TWILIO_FROM_NUMBER);
}

function escapeHtml(value: string) {
  return value.replace(/[&<>'"]/g, character => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", "'": "&#39;", '"': "&quot;" })[character] ?? character);
}

function formatAppointmentTime(value: Date, timeZone = "UTC") {
  return new Intl.DateTimeFormat("en", {
    weekday: "long",
    month: "long",
    day: "numeric",
    hour: "numeric",
    minute: "2-digit",
    timeZone,
    timeZoneName: "short",
  }).format(value);
}

function channelLabel(channel: string) {
  return channel === "video" ? "video consultation" : channel === "phone" ? "phone consultation" : "in-person appointment";
}

export async function getNotificationSystemStatus() {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const [settings] = await db.select().from(notificationSettings).where(eq(notificationSettings.id, 1)).limit(1);
  return {
    emailConfigured: hasEmailProvider(),
    smsConfigured: hasSmsProvider(),
    scheduleRegistered: Boolean(settings?.reminderTaskUid),
    enabled: settings?.enabled !== 0,
    lastRunAt: settings?.lastRunAt ?? null,
  };
}

export async function getNotificationPreferences(userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const [preference] = await db.select().from(notificationPreferences).where(eq(notificationPreferences.userId, userId)).limit(1);
  return preference ?? {
    id: 0,
    userId,
    phoneE164: null,
    emailOptIn: 1,
    smsOptIn: 0,
    staffReminderOptIn: 1,
    createdAt: null,
    updatedAt: null,
  };
}

export async function saveNotificationPreferences(input: {
  userId: number;
  phoneE164: string | null;
  emailOptIn: boolean;
  smsOptIn: boolean;
  staffReminderOptIn: boolean;
}) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const now = new Date();
  await db.insert(notificationPreferences).values({
    userId: input.userId,
    phoneE164: input.phoneE164,
    emailOptIn: input.emailOptIn ? 1 : 0,
    smsOptIn: input.smsOptIn ? 1 : 0,
    staffReminderOptIn: input.staffReminderOptIn ? 1 : 0,
    updatedAt: now,
  }).onDuplicateKeyUpdate({
    set: {
      phoneE164: input.phoneE164,
      emailOptIn: input.emailOptIn ? 1 : 0,
      smsOptIn: input.smsOptIn ? 1 : 0,
      staffReminderOptIn: input.staffReminderOptIn ? 1 : 0,
      updatedAt: now,
    },
  });
  return getNotificationPreferences(input.userId);
}

export async function getRecentNotificationDeliveries(limit = 60) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  return db.select().from(notificationDeliveries).orderBy(desc(notificationDeliveries.createdAt)).limit(limit);
}

async function sendEmail(input: { to: string; subject: string; text: string; html: string }) {
  if (!hasEmailProvider()) throw new Error("EMAIL_PROVIDER_NOT_CONFIGURED");
  const response = await fetch("https://api.resend.com/emails", {
    method: "POST",
    headers: {
      Authorization: `Bearer ${process.env.RESEND_API_KEY}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({ from: process.env.RESEND_FROM_EMAIL, to: [input.to], subject: input.subject, text: input.text, html: input.html }),
  });
  const body = await response.text();
  if (!response.ok) throw new Error(`RESEND_${response.status}: ${body.slice(0, 500)}`);
  try {
    return (JSON.parse(body) as { id?: string }).id ?? null;
  } catch {
    return null;
  }
}

async function sendSms(input: { to: string; text: string }) {
  if (!hasSmsProvider()) throw new Error("SMS_PROVIDER_NOT_CONFIGURED");
  const accountSid = process.env.TWILIO_ACCOUNT_SID ?? "";
  const auth = Buffer.from(`${accountSid}:${process.env.TWILIO_AUTH_TOKEN ?? ""}`).toString("base64");
  const response = await fetch(`https://api.twilio.com/2010-04-01/Accounts/${accountSid}/Messages.json`, {
    method: "POST",
    headers: { Authorization: `Basic ${auth}`, "Content-Type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams({ To: input.to, From: process.env.TWILIO_FROM_NUMBER ?? "", Body: input.text }),
  });
  const body = await response.text();
  if (!response.ok) throw new Error(`TWILIO_${response.status}: ${body.slice(0, 500)}`);
  try {
    return (JSON.parse(body) as { sid?: string }).sid ?? null;
  } catch {
    return null;
  }
}

type ReminderTask = {
  appointmentId: number;
  recipientUserId: number;
  channel: NotificationChannel;
  kind: NotificationKind;
  recipient: string;
  subject: string;
  text: string;
  html: string;
};

function buildTask(input: {
  appointmentId: number;
  recipientUserId: number;
  channel: NotificationChannel;
  kind: NotificationKind;
  recipient: string;
  recipientName: string;
  provider: typeof careProviders.$inferSelect;
  appointment: typeof appointments.$inferSelect;
  isStaff: boolean;
}): ReminderTask {
  const when = formatAppointmentTime(input.appointment.startsAt, input.provider.timezone);
  const subject = input.isStaff ? `MediMATCH staff reminder · ${when}` : `MediMATCH appointment reminder · ${when}`;
  const greeting = input.recipientName ? `Hi ${input.recipientName},` : "Hello,";
  const text = input.isStaff
    ? `${greeting}\n\nA patient appointment is coming up with ${input.provider.name} at ${when}.\nChannel: ${channelLabel(input.appointment.channel)}\n\nOpen the MediMATCH care desk to review the queue.`
    : `${greeting}\n\nThis is a reminder for your MediMATCH ${channelLabel(input.appointment.channel)} with ${input.provider.name} at ${when}.\n\nYour care team will keep the appointment status updated in the patient portal. This reminder is not medical advice or an emergency service.`;
  const html = `<div style="font-family:Arial,sans-serif;line-height:1.6;color:#12345b"><p>${escapeHtml(greeting)}</p><p>${escapeHtml(input.isStaff ? `A patient appointment is coming up with ${input.provider.name} at ${when}.` : `This is a reminder for your MediMATCH ${channelLabel(input.appointment.channel)} with ${input.provider.name} at ${when}.`)}</p><p><strong>Channel:</strong> ${escapeHtml(channelLabel(input.appointment.channel))}</p><p style="color:#6b7d90;font-size:13px">${escapeHtml(input.isStaff ? "Open the MediMATCH care desk to review the queue." : "Your care team will keep the appointment status updated in the patient portal. This reminder is not medical advice or an emergency service.")}</p></div>`;
  return { ...input, subject, text, html };
}

async function claimDelivery(task: ReminderTask, now: Date) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const dedupeKey = `${task.appointmentId}:${task.recipientUserId}:${task.channel}:${task.kind}`;
  let [row] = await db.select().from(notificationDeliveries).where(eq(notificationDeliveries.dedupeKey, dedupeKey)).limit(1);
  if (!row) {
    try {
      await db.insert(notificationDeliveries).values({
        appointmentId: task.appointmentId,
        recipientUserId: task.recipientUserId,
        channel: task.channel,
        kind: task.kind,
        dedupeKey,
        recipient: task.recipient,
        subject: task.subject,
        status: "pending",
        updatedAt: now,
      });
    } catch {
      // Another scheduler instance may have created this unique outbox row.
    }
    [row] = await db.select().from(notificationDeliveries).where(eq(notificationDeliveries.dedupeKey, dedupeKey)).limit(1);
  }
  if (!row || row.status === "sent" || row.status === "skipped") return null;
  const staleBefore = new Date(now.getTime() - 10 * 60 * 1000);
  const result = await db.update(notificationDeliveries).set({ status: "sending", updatedAt: now }).where(and(
    eq(notificationDeliveries.id, row.id),
    or(
      eq(notificationDeliveries.status, "pending"),
      eq(notificationDeliveries.status, "failed"),
      and(eq(notificationDeliveries.status, "sending"), lt(notificationDeliveries.updatedAt, staleBefore)),
    ),
  ));
  const affectedRows = Number((result as unknown as { affectedRows?: number }).affectedRows ?? 0);
  return affectedRows === 1 ? row.id : null;
}

async function finishDelivery(id: number, status: "sent" | "failed", now: Date, providerMessageId: string | null, error: string | null) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db.update(notificationDeliveries).set({ status, sentAt: status === "sent" ? now : null, providerMessageId, error, updatedAt: now }).where(eq(notificationDeliveries.id, id));
}

function selectedWindow(hoursUntilStart: number, isStaff: boolean): { kind: NotificationKind; minHours: number; maxHours: number } | null {
  return REMINDER_WINDOWS.find(window => window.kind.startsWith(isStaff ? "staff" : "patient") && hoursUntilStart >= window.minHours && hoursUntilStart < window.maxHours) ?? null;
}

export async function runAppointmentReminderSweep(now = new Date()) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const horizonEnd = new Date(now.getTime() + 25 * 60 * 60 * 1000);
  const rows = await db.select({ appointment: appointments, provider: careProviders, patient: users })
    .from(appointments)
    .innerJoin(careProviders, eq(appointments.providerId, careProviders.id))
    .innerJoin(users, eq(appointments.patientUserId, users.id))
    .where(and(gte(appointments.startsAt, now), lt(appointments.startsAt, horizonEnd), inArray(appointments.status, activeStatuses)))
    .orderBy(asc(appointments.startsAt));
  const staff = await db.select().from(users).where(or(eq(users.role, "admin"), eq(users.accountType, "admin")));
  const preferenceIds = [...new Set([...rows.map(row => row.patient.id), ...staff.map(user => user.id)])];
  const preferenceRows = preferenceIds.length ? await db.select().from(notificationPreferences).where(inArray(notificationPreferences.userId, preferenceIds)) : [];
  const preferenceMap = new Map(preferenceRows.map(row => [row.userId, row]));
  let matched = 0;
  let attempted = 0;
  let sent = 0;
  let failed = 0;
  let skipped = 0;

  const deliver = async (task: ReminderTask) => {
    const id = await claimDelivery(task, now);
    if (!id) return;
    attempted += 1;
    try {
      const providerMessageId = task.channel === "email"
        ? await sendEmail({ to: task.recipient, subject: task.subject, text: task.text, html: task.html })
        : await sendSms({ to: task.recipient, text: task.text });
      await finishDelivery(id, "sent", now, providerMessageId, null);
      sent += 1;
    } catch (error) {
      await finishDelivery(id, "failed", now, null, error instanceof Error ? error.message : String(error));
      failed += 1;
    }
  };

  for (const row of rows) {
    const hoursUntilStart = (row.appointment.startsAt.getTime() - now.getTime()) / 3_600_000;
    const patientWindow = selectedWindow(hoursUntilStart, false);
    const staffWindow = selectedWindow(hoursUntilStart, true);
    if (!patientWindow && !staffWindow) continue;
    matched += 1;
    const patientPreferences = preferenceMap.get(row.patient.id);
    const patientTaskBase = patientWindow ? { appointmentId: row.appointment.id, recipientUserId: row.patient.id, kind: patientWindow.kind, recipientName: row.patient.name ?? "", provider: row.provider, appointment: row.appointment, isStaff: false } : null;
    if (patientTaskBase && row.patient.email && patientPreferences?.emailOptIn !== 0) {
      await deliver(buildTask({ ...patientTaskBase, channel: "email", recipient: row.patient.email }));
    } else if (patientTaskBase && !row.patient.email) {
      skipped += 1;
    }
    if (patientTaskBase && patientPreferences?.smsOptIn === 1 && patientPreferences.phoneE164) {
      await deliver(buildTask({ ...patientTaskBase, channel: "sms", recipient: patientPreferences.phoneE164 }));
    }
    for (const staffUser of staff) {
      if (!staffWindow) continue;
      const staffPreferences = preferenceMap.get(staffUser.id);
      const staffTaskBase = { appointmentId: row.appointment.id, recipientUserId: staffUser.id, kind: staffWindow.kind, recipientName: staffUser.name ?? "MediMATCH staff", provider: row.provider, appointment: row.appointment, isStaff: true };
      if (staffUser.email && staffPreferences?.emailOptIn !== 0 && staffPreferences?.staffReminderOptIn !== 0) {
        await deliver(buildTask({ ...staffTaskBase, channel: "email", recipient: staffUser.email }));
      } else if (staffUser.email && staffPreferences?.staffReminderOptIn === 0) {
        skipped += 1;
      }
      if (staffPreferences?.smsOptIn === 1 && staffPreferences.phoneE164 && staffPreferences.staffReminderOptIn !== 0) {
        await deliver(buildTask({ ...staffTaskBase, channel: "sms", recipient: staffPreferences.phoneE164 }));
      }
    }
  }

  await db.insert(notificationSettings).values({ id: 1, enabled: 1, lastRunAt: now, updatedAt: now }).onDuplicateKeyUpdate({ set: { lastRunAt: now, updatedAt: now } });
  return { examined: rows.length, matched, attempted, sent, failed, skipped, emailConfigured: hasEmailProvider(), smsConfigured: hasSmsProvider() };
}

export async function getReminderSettings() {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const [settings] = await db.select().from(notificationSettings).where(eq(notificationSettings.id, 1)).limit(1);
  return settings ?? null;
}

export async function saveReminderTaskUid(taskUid: string) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const now = new Date();
  await db.insert(notificationSettings).values({ id: 1, reminderTaskUid: taskUid, enabled: 1, updatedAt: now }).onDuplicateKeyUpdate({ set: { reminderTaskUid: taskUid, enabled: 1, updatedAt: now } });
  return getReminderSettings();
}
