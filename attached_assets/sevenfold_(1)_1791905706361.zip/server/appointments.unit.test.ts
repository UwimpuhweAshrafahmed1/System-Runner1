import { describe, expect, it } from "vitest";
import { candidateSlotsForDate, isStaff, validateSlotDate } from "./appointments";

describe("appointment availability", () => {
  it("creates sixteen half-hour slots for a weekday", () => {
    const slots = candidateSlotsForDate("2026-10-05");
    expect(slots).toHaveLength(16);
    expect(slots[0]?.toISOString()).toBe("2026-10-05T09:00:00.000Z");
    expect(slots.at(-1)?.toISOString()).toBe("2026-10-05T16:30:00.000Z");
  });

  it("does not offer weekend slots", () => {
    expect(candidateSlotsForDate("2026-10-03")).toHaveLength(0);
  });

  it("accepts only exact thirty-minute slot boundaries", () => {
    expect(validateSlotDate(new Date("2026-10-05T10:30:00.000Z"))).toBe(true);
    expect(validateSlotDate(new Date("2026-10-05T10:20:00.000Z"))).toBe(false);
  });

  it("limits staff actions to admin users", () => {
    expect(isStaff({ role: "admin" } as any)).toBe(true);
    expect(isStaff({ role: "user" } as any)).toBe(false);
  });
});
